// Agent.cc

#include <iostream>
#include "Agent.h"
#include <ctime>

using namespace std;

Agent::Agent()
{
    Initialize();
}

Agent::~Agent()
{
}

void Agent::Initialize()
{
    agentLocation = Location(1, 1);
    agentOrientation = RIGHT;
    hasArrow = true;
    hasGold = false;
    rng.seed(std::time(0));  // seed the random number generator
}

Action Agent::Process(Percept& percept) {
    if (percept.Glitter) {
        return GrabGold();
    }

    if (IsAtStartLocation() && hasGold) {
        return CLIMB;
    }

    if (CanShoot()) {
        return SHOOT;
    }

    return randomMove();
}

Action Agent::GrabGold() {
    hasGold = true;
    return GRAB;
}

bool Agent::IsAtStartLocation() {
    return agentLocation.X == 1 && agentLocation.Y == 1;
}

bool Agent::CanShoot() {
    return hasArrow && 
           ((agentLocation.Y == 4 && agentOrientation == RIGHT) ||
            (agentLocation.X == 4 && agentOrientation == UP));
}

Action Agent::randomMove() {
    std::uniform_int_distribution<int> dist(0, 2);
    int randomAction = dist(rng);
    switch (randomAction) {
        case 0: return GOFORWARD;
        case 1: return TURNLEFT;
        case 2: return TURNRIGHT;
    }
    return GOFORWARD; // This line should never be reached
}

void Agent::UpdateState(Action action) {
    switch (action) {
        case GOFORWARD:
            MoveForward();
            break;
        case TURNLEFT:
            TurnLeft();
            break;
        case TURNRIGHT:
            TurnRight();
            break;
        default:
            break;
    }
}

void Agent::MoveForward() {
    switch (agentOrientation) {
        case UP: if (agentLocation.Y < 4) agentLocation.Y++; break;
        case DOWN: if (agentLocation.Y > 1) agentLocation.Y--; break;
        case LEFT: if (agentLocation.X > 1) agentLocation.X--; break;
        case RIGHT: if (agentLocation.X < 4) agentLocation.X++; break;
    }
}

void Agent::TurnLeft() {
    switch (agentOrientation) {
        case UP: agentOrientation = LEFT; break;
        case DOWN: agentOrientation = RIGHT; break;
        case LEFT: agentOrientation = DOWN; break;
        case RIGHT: agentOrientation = UP; break;
    }
}

void Agent::TurnRight() {
    switch (agentOrientation) {
        case UP: agentOrientation = RIGHT; break;
        case DOWN: agentOrientation = LEFT; break;
        case LEFT: agentOrientation = UP; break;
        case RIGHT: agentOrientation = DOWN; break;
    }
}

void Agent::GameOver(int score) {
    cout << "Game Over. Score: " << score << endl;
}