// Agent.h

#ifndef AGENT_H
#define AGENT_H

#include <iostream>
#include <random>
#include "Location.h"
#include "Percept.h"
#include "Action.h"
#include "Orientation.h"


class Agent {
public:
    Agent();
    ~Agent();
    Action Process(Percept& percept);
    void UpdateState(Action action);
    void GameOver(int score);
	void Initialize();

private:
    
    Action GrabGold();
    bool IsAtStartLocation();
    bool CanShoot();
    Action randomMove();
    void MoveForward();
    void TurnLeft();
    void TurnRight();

    Location agentLocation;
    Orientation agentOrientation;
    bool hasArrow;
    bool hasGold;
    std::random_device rd;
    std::mt19937 rng;
};

#endif  // AGENT_H